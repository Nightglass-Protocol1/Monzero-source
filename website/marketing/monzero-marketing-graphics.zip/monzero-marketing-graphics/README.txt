Monzero (XMZ) marketing graphics
Official artwork for posts, profiles and banners. Do not recolour, stretch or add effects to
the logos. Never post an image that shows a real recovery phrase or private key.
Key messages, ready-to-post copy and rules: https://monzero.org/marketing/
Press and listing kit: https://monzero.org/press/
