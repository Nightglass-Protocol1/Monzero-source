pragma Singleton

import QtQuick 2.5

QtObject {
    property bool blackTheme: true
    property QtObject fontMedium: FontLoader { id: _fontMedium; source: "qrc:/fonts/Roboto-Medium.ttf"; }
    property QtObject fontBold: FontLoader { id: _fontBold; source: "qrc:/fonts/Roboto-Bold.ttf"; }
    property QtObject fontLight: FontLoader { id: _fontLight; source: "qrc:/fonts/Roboto-Light.ttf"; }
    property QtObject fontRegular: FontLoader { id: _fontRegular; source: "qrc:/fonts/Roboto-Regular.ttf"; }

    property QtObject fontMonoMedium: FontLoader { id: _fontMonoMedium; source: "qrc:/fonts/RobotoMono-Medium.ttf"; }
    property QtObject fontMonoBold: FontLoader { id: _fontMonoBold; source: "qrc:/fonts/RobotoMono-Bold.ttf"; }
    property QtObject fontMonoLight: FontLoader { id: _fontMonoLight; source: "qrc:/fonts/RobotoMono-Light.ttf"; }
    property QtObject fontMonoRegular: FontLoader { id: _fontMonoRegular; source: "qrc:/fonts/RobotoMono-Regular.ttf"; }

    // Monzero Nightshade: purple is the brand/action colour while amber stays
    // reserved for warnings.  Keep the legacy `orange` name because it is the
    // accent token used throughout the upstream QML component set.
    property string grey: "#352F43"
    property string orange: "#A970FF"
    property string white: "#FFFFFF"
    property string green: "#55D6A7"
    property string moneroGrey: "#423A54"
    property string warningColor: "#FFB454"
    property string accent: "#A970FF"
    property string accentBright: "#C9A7FF"
    property string accentMuted: "#7451A8"
    property string surfaceRaised: "#211A2E"

    property string defaultFontColor: blackTheme ? _b_defaultFontColor : _w_defaultFontColor
    property string dimmedFontColor: blackTheme ? _b_dimmedFontColor : _w_dimmedFontColor
    property string lightGreyFontColor: blackTheme ? _b_lightGreyFontColor : _w_lightGreyFontColor
    property string errorColor: blackTheme ? _b_errorColor : _w_errorColor
    property string textSelectionColor: blackTheme ? _b_textSelectionColor : _w_textSelectionColor
    property string textSelectedColor: blackTheme ? _b_textSelectedColor : _w_textSelectedColor

    property string inputBoxBackground: blackTheme ? _b_inputBoxBackground : _w_inputBoxBackground
    property string inputBoxBackgroundDisabled: blackTheme ? _b_inputBoxBackgroundDisabled : _w_inputBoxBackgroundDisabled
    property string inputBoxBackgroundError: blackTheme ? _b_inputBoxBackgroundError : _w_inputBoxBackgroundError
    property string inputBoxColor: blackTheme ? _b_inputBoxColor : _w_inputBoxColor
    property string legacy_placeholderFontColor: blackTheme ? _b_legacy_placeholderFontColor : _w_legacy_placeholderFontColor
    property string inputBorderColorActive: blackTheme ? _b_inputBorderColorActive : _w_inputBorderColorActive
    property string inputBorderColorInActive: blackTheme ? _b_inputBorderColorInActive : _w_inputBorderColorInActive
    property string inputBorderColorInvalid: blackTheme ? _b_inputBorderColorInvalid : _w_inputBorderColorInvalid

    property string buttonBackgroundColor: blackTheme ? _b_buttonBackgroundColor : _w_buttonBackgroundColor
    property string buttonBackgroundColorHover: blackTheme ? _b_buttonBackgroundColorHover : _w_buttonBackgroundColorHover
    property string buttonBackgroundColorDisabled: blackTheme ? _b_buttonBackgroundColorDisabled : _w_buttonBackgroundColorDisabled
    property string buttonBackgroundColorDisabledHover: blackTheme ? _b_buttonBackgroundColorDisabledHover : _w_buttonBackgroundColorDisabledHover
    property string buttonInlineBackgroundColor: blackTheme ? _b_buttonInlineBackgroundColor : _w_buttonInlineBackgroundColor
    property string buttonInlineBackgroundColorHover: blackTheme ? _b_buttonInlineBackgroundColorHover : _w_buttonInlineBackgroundColorHover
    property string buttonTextColor: blackTheme ? _b_buttonTextColor : _w_buttonTextColor
    property string buttonTextColorDisabled: blackTheme ? _b_buttonTextColorDisabled : _w_buttonTextColorDisabled
    property string buttonSecondaryBackgroundColor: blackTheme ? _b_buttonSecondaryBackgroundColor : _w_buttonSecondaryBackgroundColor
    property string buttonSecondaryBackgroundColorHover: blackTheme ? _b_buttonSecondaryBackgroundColorHover : _w_buttonSecondaryBackgroundColorHover
    property string buttonSecondaryTextColor: blackTheme ? _b_buttonSecondaryTextColor : _w_buttonSecondaryTextColor
    property string dividerColor: blackTheme ? _b_dividerColor : _w_dividerColor
    property real dividerOpacity: blackTheme ? _b_dividerOpacity : _w_dividerOpacity

    property string titleBarBackgroundGradientStart: blackTheme ? _b_titleBarBackgroundGradientStart : _w_titleBarBackgroundGradientStart
    property string titleBarBackgroundGradientStop: blackTheme ? _b_titleBarBackgroundGradientStop : _w_titleBarBackgroundGradientStop
    property string titleBarBackgroundBorderColor: blackTheme ? _b_titleBarBackgroundBorderColor : _w_titleBarBackgroundBorderColor
    property string titleBarLogoSource: blackTheme ? _b_titleBarLogoSource : _w_titleBarLogoSource
    property string titleBarMinimizeSource: blackTheme ? _b_titleBarMinimizeSource : _w_titleBarMinimizeSource
    property string titleBarFullscreenSource: blackTheme ? _b_titleBarFullscreenSource : _w_titleBarFullscreenSource
    property string titleBarCloseSource: blackTheme ? _b_titleBarCloseSource : _w_titleBarCloseSource
    property string titleBarButtonHoverColor: blackTheme ? _b_titleBarButtonHoverColor : _w_titleBarButtonHoverColor

    property string wizardBackgroundGradientStart: blackTheme ? _b_wizardBackgroundGradientStart : _w_wizardBackgroundGradientStart
    property string middlePanelBackgroundGradientStart: blackTheme ? _b_middlePanelBackgroundGradientStart : _w_middlePanelBackgroundGradientStart
    property string middlePanelBackgroundGradientStop: blackTheme ? _b_middlePanelBackgroundGradientStop : _w_middlePanelBackgroundGradientStop
    property string middlePanelBackgroundColor: blackTheme ? _b_middlePanelBackgroundColor : _w_middlePanelBackgroundColor
    property string menuButtonFallbackBackgroundColor: blackTheme ? _b_menuButtonFallbackBackgroundColor : _w_menuButtonFallbackBackgroundColor
    property string menuButtonGradientStart: blackTheme ? _b_menuButtonGradientStart : _w_menuButtonGradientStart
    property string menuButtonGradientStop: blackTheme ? _b_menuButtonGradientStop : _w_menuButtonGradientStop
    property string menuButtonTextColor: blackTheme ? _b_menuButtonTextColor : _w_menuButtonTextColor
    property string menuButtonImageRightColorActive: blackTheme ? _b_menuButtonImageRightColorActive : _w_menuButtonImageRightColorActive
    property string menuButtonImageRightColor: blackTheme ? _b_menuButtonImageRightColor : _w_menuButtonImageRightColor
    property string menuButtonImageRightSource: blackTheme ? _b_menuButtonImageRightSource : _w_menuButtonImageRightSource
    property string menuButtonImageDotArrowSource: blackTheme ? _b_menuButtonImageDotArrowSource : _w_menuButtonImageDotArrowSource
    property string inlineButtonTextColor: blackTheme ? _b_inlineButtonTextColor : _w_inlineButtonTextColor
    property string inlineButtonBorderColor: blackTheme ? _b_inlineButtonBorderColor : _w_inlineButtonBorderColor
    property string appWindowBackgroundColor: blackTheme ? _b_appWindowBackgroundColor : _w_appWindowBackgroundColor
    property string appWindowBorderColor: blackTheme ? _b_appWindowBorderColor : _w_appWindowBorderColor
    property bool progressBarProgressTextBold: blackTheme ? _b_progressBarProgressTextBold : _w_progressBarProgressTextBold
    property string progressBarBackgroundColor: blackTheme ? _b_progressBarBackgroundColor : _w_progressBarBackgroundColor
    property string leftPanelBackgroundGradientStart: blackTheme ? _b_leftPanelBackgroundGradientStart : _w_leftPanelBackgroundGradientStart
    property string leftPanelBackgroundGradientStop: blackTheme ? _b_leftPanelBackgroundGradientStop : _w_leftPanelBackgroundGradientStop
    property string historyHeaderTextColor: blackTheme ? _b_historyHeaderTextColor : _w_historyHeaderTextColor
    property var accountColors: blackTheme ? _b_accountColors : _w_accountColors

    property string _b_defaultFontColor: "#F7F3FF"
    property string _b_dimmedFontColor: "#B9AEC9"
    property string _b_lightGreyFontColor: "#DDD4EA"
    property string _b_errorColor: "#FF6B8A"
    property string _b_textSelectionColor: "#7451A8"
    property string _b_textSelectedColor: "white"

    property string _b_inputBoxBackground: "#120E19"
    property string _b_inputBoxBackgroundDisabled: "#292234"
    property string _b_inputBoxBackgroundError: "#351A2A"
    property string _b_inputBoxColor: "#F7F3FF"
    property string _b_legacy_placeholderFontColor: "#8F839F"
    property string _b_inputBorderColorActive: "#A970FF"
    property string _b_inputBorderColorInActive: "#493D5D"
    property string _b_inputBorderColorInvalid: "#FF6B8A"

    property string _b_buttonBackgroundColor: "#8657D9"
    property string _b_buttonBackgroundColorHover: "#A970FF"
    property string _b_buttonBackgroundColorDisabled: "#4B4258"
    property string _b_buttonBackgroundColorDisabledHover: "#554A64"
    property string _b_buttonInlineBackgroundColor: "#352C46"
    property string _b_buttonInlineBackgroundColorHover: "#493661"
    property string _b_buttonTextColor: "white"
    property string _b_buttonTextColorDisabled: "#B9AEC9"
    property string _b_buttonSecondaryBackgroundColor: "#30273F"
    property string _b_buttonSecondaryBackgroundColorHover: "#493661"
    property string _b_buttonSecondaryTextColor: "#E9DEFF"
    property string _b_dividerColor: "#B990FF"
    property real _b_dividerOpacity: 0.24

    property string _b_titleBarBackgroundGradientStart: "#251B35";
    property string _b_titleBarBackgroundGradientStop: "#120D1B"
    property string _b_titleBarBackgroundBorderColor: "#493661"
    property string _b_titleBarLogoSource: "qrc:///images/titlebarLogo.png"
    property string _b_titleBarMinimizeSource: "qrc:///images/minimize.svg"
    property string _b_titleBarFullscreenSource: "qrc:///images/fullscreen.svg"
    property string _b_titleBarCloseSource: "qrc:///images/close.svg"
    property string _b_titleBarButtonHoverColor: "#354A2270"

    property string _b_wizardBackgroundGradientStart: "#181121"
    property string _b_middlePanelBackgroundGradientStart: "#20182B"
    property string _b_middlePanelBackgroundGradientStop: "#0E0A14"
    property string _b_middlePanelBackgroundColor: "#15101E"
    property string _b_menuButtonFallbackBackgroundColor: "#40305B"
    property string _b_menuButtonGradientStart: "#59407F"
    property string _b_menuButtonGradientStop: "#00000000"
    property string _b_menuButtonTextColor: "#E9DEFF"
    property string _b_menuButtonImageRightColorActive: "#C9A7FF"
    property string _b_menuButtonImageRightColor: "#9B8CAB"
    property string _b_menuButtonImageRightSource: "qrc:///images/right.svg"
    property string _b_menuButtonImageDotArrowSource: "qrc:///images/arrow-right-medium-white.png"
    property string _b_inlineButtonTextColor: "#C9A7FF"
    property string _b_inlineButtonBorderColor: "#493661"
    property string _b_appWindowBackgroundColor: "#0C0911"
    property string _b_appWindowBorderColor: "#493661"
    property bool _b_progressBarProgressTextBold: true
    property string _b_progressBarBackgroundColor: "#33493661"
    property string _b_leftPanelBackgroundGradientStart: "#241A32"
    property string _b_leftPanelBackgroundGradientStop: "#120D1A"
    property string _b_historyHeaderTextColor: "#C9BCE0"
    property var _b_accountColors: ["#A970FF", "#D66DFF", "#756BFF", "#53B9D6", "#55D6A7", "#E3A85B", "#E76D9B", "#8E7AB5"]

    property string _w_defaultFontColor: "black"
    property string _w_dimmedFontColor: "#3f3f3f"
    property string _w_lightGreyFontColor: "#515151"
    property string _w_errorColor: "#FA6800"
    property string _w_textSelectionColor: "#BBBBBB"
    property string _w_textSelectedColor: "black"

    property string _w_inputBoxBackground: "white"
    property string _w_inputBoxBackgroundDisabled: Qt.rgba(0, 0, 0, 0.20)
    property string _w_inputBoxBackgroundError: "#FFDDDD"
    property string _w_inputBoxColor: "black"
    property string _w_legacy_placeholderFontColor: "#BABABA"
    property string _w_inputBorderColorActive: Qt.rgba(0, 0, 0, 0.30)
    property string _w_inputBorderColorInActive: Qt.rgba(0, 0, 0, 0.16)
    property string _w_inputBorderColorInvalid: Qt.rgba(255, 0, 0, 0.50)

    property string _w_buttonBackgroundColor: "#FA6800"
    property string _w_buttonBackgroundColorHover: "#E65E00"
    property string _w_buttonBackgroundColorDisabled: "#bbbbbb"
    property string _w_buttonBackgroundColorDisabledHover: "#D1D1D1"
    property string _w_buttonInlineBackgroundColor: "#d9d9d9"
    property string _w_buttonInlineBackgroundColorHover: "#C8C8C8"
    property string _w_buttonTextColor: "white"
    property string _w_buttonTextColorDisabled: "black"
    property string _w_buttonSecondaryBackgroundColor: "#d9d9d9"
    property string _w_buttonSecondaryBackgroundColorHover: "#C8C8C8"
    property string _w_buttonSecondaryTextColor: "#4d4d4d"
    property string _w_dividerColor: "black"
    property real _w_dividerOpacity: 0.20

    property string _w_titleBarBackgroundGradientStart: "#fcfcfc"
    property string _w_titleBarBackgroundGradientStop: "#FBFBFB"
    property string _w_titleBarBackgroundBorderColor: "#DEDEDE"
    property string _w_titleBarLogoSource: "qrc:///images/themes/white/titlebarLogo.png"
    property string _w_titleBarMinimizeSource: "qrc:///images/themes/white/minimize.svg"
    property string _w_titleBarFullscreenSource: "qrc:///images/themes/white/fullscreen.svg"
    property string _w_titleBarCloseSource: "qrc:///images/themes/white/close.svg"
    property string _w_titleBarButtonHoverColor: "#11000000"

    property string _w_wizardBackgroundGradientStart: "white"
    property string _w_middlePanelBackgroundGradientStart: "white"
    property string _w_middlePanelBackgroundGradientStop: "#ededed"
    property string _w_middlePanelBackgroundColor: "#f5f5f5"
    property string _w_menuButtonFallbackBackgroundColor: "#09000000"
    property string _w_menuButtonGradientStart: "#08000000"
    property string _w_menuButtonGradientStop: "#10FFFFFF"
    property string _w_menuButtonTextColor: "#787878"
    property string _w_menuButtonImageRightSource: "qrc:///images/right.svg"
    property string _w_menuButtonImageRightColorActive: "#FA6800"
    property string _w_menuButtonImageRightColor: "#808080"
    property string _w_menuButtonImageDotArrowSource: "qrc:///images/arrow-right-medium-white.png"
    property string _w_inlineButtonTextColor: "#4d4d4d"
    property string _w_inlineButtonBorderColor: "transparent"
    property string _w_appWindowBackgroundColor: "black"
    property string _w_appWindowBorderColor: "#dedede"
    property bool _w_progressBarProgressTextBold: false
    property string _w_progressBarBackgroundColor: "#24000000"
    property string _w_leftPanelBackgroundGradientStart: "white"
    property string _w_leftPanelBackgroundGradientStop: "#f5f5f5"
    property string _w_historyHeaderTextColor: "#515151"
    property var _w_accountColors: ["#6E513C", "#6E513C", "#842129", "#458421", "#742184", "#291DBE", "#846F21", "#217F84", "#696969"]
}
