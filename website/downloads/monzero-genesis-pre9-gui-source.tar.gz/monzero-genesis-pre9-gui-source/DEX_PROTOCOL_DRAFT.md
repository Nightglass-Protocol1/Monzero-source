# Monzero private DEX protocol draft

Status: inactive design document. No public network accepts DEX orders or
settlements, and the GUI must keep live execution disabled.

## Markets and custody

The initial market family is BTC/XMZ, LTC/XMZ, and BCH/XMZ. Orders are intended
to settle through non-custodial, chain-specific atomic swaps. The exchange must
not accept account deposits, hold customer keys, fabricate balances, or treat
reference-market data as an executable quote.

## Fee policy

Every preview must separately disclose:

1. the gross traded amounts;
2. the XMZ protocol fee;
3. the Monzero network fee;
4. the BTC, LTC, or BCH miner fee; and
5. the net amounts each party receives.

The protocol fee is denominated and collected only in XMZ. There is no
external-coin service or treasury fee. External coin is used only for the trade
principal and its native miner fee. A permanent or reusable BTC, LTC, or BCH
fee address is forbidden.

Buying XMZ must not require an existing XMZ balance. The seller locks enough
XMZ to cover the quoted proceeds and Monzero-side fees. On successful
settlement, the buyer receives the quoted XMZ less the disclosed protocol and
network fees.

Protocol revenue is earned only by a successfully completed swap. Expired,
cancelled, failed, or refunded swaps pay no protocol fee. Each chain may still
consume an unavoidable miner fee for an already-broadcast lock or refund
transaction; the confirmation screen must explain that risk before signing.

## Safety invariants

- Live trading remains disabled unless every chain adapter is explicitly
  compiled, configured, synchronized, and healthy.
- A quote cannot become an order without explicit confirmation of all fees,
  timelocks, minimum confirmations, and refund deadlines.
- Fees cannot make either net settlement output zero, negative, dust, or below
  the configured minimum trade size.
- The protocol fee output must be bound to the same successful settlement as
  the trade and cannot be paid by a refund path.
- Price feeds are display-only. Signed orders and completed swaps determine the
  DEX price.
- No private key, seed, preimage, adaptor secret, or unsigned transaction may
  be written to logs or market-data storage.

## Work still required

Chain adapters, atomic-swap cryptography, signed order relay, persistence,
reorganisation handling, fee estimation, refund recovery, adversarial tests,
isolated testnets, independent security review, and applicable legal review
are prerequisites for any public activation.
