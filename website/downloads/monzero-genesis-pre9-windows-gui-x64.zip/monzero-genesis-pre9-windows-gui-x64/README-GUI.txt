MONZERO GENESIS PRE9 - UNTESTED WINDOWS GRAPHICAL WALLET

Run start-wallet-gui.bat or monzero-wallet-gui.exe. The package includes the
matching pre9 daemon and command-line tools. The GUI may start monzerod.exe
from this directory when local-node mode is selected.

Create a new Monzero-only wallet. Never open a Monero wallet here and never
reuse a Monero seed, keys, or wallet files. Back up the recovery seed offline
before receiving funds.

This GUI is unsigned, unaudited, deliberately untested prerelease software.
It was cross-compiled in the pinned static Windows environment, but no test
suite, PE/import verifier, native Windows startup, wallet restoration,
synchronization, or transfer test was run for the exact pre9 archive. Earlier
pre8 evidence does not qualify these binaries. The GUI does not activate the
unscheduled asset protocol. Verify SHA256SUMS before running any executable.

GUI source:  f31aba2332009ebc0b4a278a1291f98ec2bb868a
Core source: 782d9c28645816aabb4f558e43e9ce5497fa1ef3
